package mx.edu.itchetumal.formulario

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import mx.edu.itchetumal.formulario.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding

    private var index:Int = 0;

    private var bancoPreguntas = listOf<Preguntas>(
        Preguntas(R.string.question_1,false),
        Preguntas(R.string.question_2,true),
        Preguntas(R.string.question_3,false),
        Preguntas(R.string.question_4,true),
        Preguntas(R.string.question_5,true)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnTrue.setOnClickListener{
            Toast.makeText(this,"Correcto", Toast.LENGTH_SHORT).show()
        }

        binding.btNext.setOnClickListener {
            index = (index + 1) % bancoPreguntas.size
            updatePregunta()
        }
        updatePregunta()
    }

    private fun updatePregunta(){
        val preguntaResId = bancoPreguntas[index].textResId
        binding.textView.setText(preguntaResId)
    }
}