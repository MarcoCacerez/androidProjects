package mx.edu.itchetumal.formulario

import androidx.annotation.StringRes

data class Preguntas (@StringRes val textResId: Int, val respuesta:Boolean){

}