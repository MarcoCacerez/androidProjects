package com.marco.calculadora

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.marco.calculadora.databinding.ActivityMainBinding
import java.util.ArrayDeque

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        var btnArray = arrayOf(
            binding.btn1,binding.btn2,binding.btn3,binding.btn4,binding.btn5,
            binding.btn6,binding.btn7,binding.btn8,binding.btn9,binding.btn0,
            binding.btnPlus,binding.btnSubtrac,binding.btnDivision,binding.btnTimes
            )
        for(btn in btnArray){
            btn.setOnClickListener { add(btn.text.toString()) }
        }
        binding.btnClear.setOnClickListener { binding.textView.text = "" }
        binding.btnEquals.setOnClickListener{calculate()}
        /*
        binding.btn2.setOnClickListener { add("2") }
        binding.btn3.setOnClickListener { add("3") }
        binding.btn4.setOnClickListener { add("4") }
        binding.btn5.setOnClickListener { add("5") }
        */
    }

    private fun add(param:String){
        val text = binding.textView.getText().toString()
        when(param){
            "+","-","*","/" -> binding.textView.text = text + " " + param + " "
            else -> binding.textView.text = text + param
        }
    }
    private fun calculate(){
        val operation = binding.textView.getText().toString()
        var postfix:String = postfix(operation)
        postfixCalculate(postfix)
        //binding.textView2.text = postfix
    }

    private fun postfix(operation : String):String{
        var arrayOperation = operation.split(" ")
        var postfix = ""
        var operatorsStack = ArrayDeque<String>()

        for (token in arrayOperation){
            when (token){
                "*","-","+","/" -> {
                    if(operatorsStack.isEmpty()){operatorsStack.push(token)}
                    else{
                        if(precedence(token) > precedence(operatorsStack.peek())){
                            operatorsStack.push(token)
                        }else{
                            while(!operatorsStack.isEmpty() && precedence(token) <= precedence(operatorsStack.peek())){
                                postfix += operatorsStack.peek() + " "
                                operatorsStack.pop()
                            }
                            operatorsStack.push(token)
                        }
                    }
                }
                else ->{
                    postfix += token + " "
                }
            }
        }

        while(!operatorsStack.isEmpty()){
            postfix += operatorsStack.peek() + " "
            operatorsStack.pop()
        }

        return postfix
    }

    private fun postfixCalculate(postfix:String){
        var postfixArray = postfix.split(" ")
        var numbersStack = ArrayDeque<String>()
        var temp: Double = 0.0
        var num1: Double = 0.0
        var num2: Double = 0.0
        for (token in postfixArray){
            when(token){
                "*" -> {
                    num2 = numbersStack.pop().toDouble()
                    num1 = numbersStack.pop().toDouble()
                    temp = num1*num2
                    numbersStack.push(temp.toString())
                }
                "/" -> {
                    num2 = numbersStack.pop().toDouble()
                    num1 = numbersStack.pop().toDouble()
                    temp = num1/num2
                    numbersStack.push(temp.toString())
                }
                "+" -> {
                    num2 = numbersStack.pop().toDouble()
                    num1 = numbersStack.pop().toDouble()
                    temp = num1+num2
                    numbersStack.push(temp.toString())
                }
                "-" -> {
                    num2 = numbersStack.pop().toDouble()
                    num1 = numbersStack.pop().toDouble()
                    temp = num1-num2
                    numbersStack.push(temp.toString())
                }
                else -> {numbersStack.push(token)}
            }
        }



        binding.textView.text = temp.toString()
    }

    private fun precedence(token: String): Int{
        return when(token){
            "*","/" -> 3
            else -> 2
        }
    }
}